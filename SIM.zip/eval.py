# -*- coding: utf-8 -*-
import cv2
import numpy as np
## TODO: Допишите импорт библиотек, которые собираетесь использовать


def load_final_model():
    """ Функция осуществляет загрузку модели нейронной сети из файла.
        Выходные параметры: загруженная модель

        Если вы не собираетесь использовать эту функцию, пусть возвращает пустой список []
        Если вы используете несколько моделей, возвращайте их список [model1, model2]
    """

    ## TODO: Отредактируйте функцию по своему усмотрению.
    ## Модель нейронной сети, загрузите вместе с решением.
    ## Если вы не собираетесь использовать эту функцию, пусть возвращает пустой список []

    # model = tensorflow.load_model(MODEL_FILE_NAME)
    model = []
    return model

def get_output_layers(net):
    
    layer_names = net.getLayerNames()

    output_layers = []
    
    for i in net.getUnconnectedOutLayers():

        output_layers.append(layer_names[i - 1] )

    return output_layers



def predict(image):
    config = './yolov4-tiny-custom.cfg'
    weights = './yolov4-tiny-custom_final.weights'
    Width = image.shape[1]
    Height = image.shape[0]
    scale = 0.00392


    classes = ['BASE']

    COLORS = np.random.uniform(0, 255, size=(1, 3))

    net = cv2.dnn.readNet(weights, config)

    blob = cv2.dnn.blobFromImage(image, scale, (1024,1024), (0,0,0), True, crop=False)

    net.setInput(blob)

    outs = net.forward(get_output_layers(net))

    class_ids = []
    confidences = []
    boxes = []
    conf_threshold = 0.5
    nms_threshold = 0.4


    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                center_x = int(detection[0] * Width)
                center_y = int(detection[1] * Height)
                w = int(detection[2] * Width)
                h = int(detection[3] * Height)
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)
                class_ids.append(class_id)
                confidences.append(float(confidence))
                boxes.append((x, y, x+w, y+h))


    #indices = cv2.dnn.NMSBoxes(boxes, confidences, conf_threshold, nms_threshold)
    return boxes



def standardize_input(image):
    standard_im = image  # по умолчанию, функция не меняет изображения
    #image = cv2.resize(image, (32, 32))
    ## TODO: Если вы хотите преобразовать изображение в формат,
    ## одинаковый для всех изображений, сделайте это здесь.

    return standard_im


def predict_boxes(image, model):
    """
         Функция, детектирующая колосья пшеницы
         Входные данные: изображение (bgr), модель нейронной сети
         Выходные данные: список с координататами ограничивающих рамок

         Формат вывода: [(x, y, x2, y2)]
                        x и y - координаты левого верхнего угла ограничивающей рамки
                        x2 и y2 - координаты правого нижнего угла ограничивающей рамки

         Примеры вывода: [(10, 14, 18, 25),
                          (110, 114, 118, 215),
                          (10, 11, 18, 15)] - если обнаружили три колоска пшеницы

                         [(10, 11, 18, 15)] - если обнаружили один колос пшеницы

                         [] - если не обнаружили колосья пшеницы
    """

    ## TODO: Отредактируйте эту функцию по своему усмотрению.
    # Алгоритм проверки будет вызывать функции load_final_model и predict_label,
    # остальные функции должны вызываться из вешеперечисленных.

    standard_im = standardize_input(image)
    # predicted_label = model.predict(standard_im)
    # predicted_label_and_box = encode(predicted_label) # приведение к верному формату
    predicted_boxes = predict(image)

    return predicted_boxes
